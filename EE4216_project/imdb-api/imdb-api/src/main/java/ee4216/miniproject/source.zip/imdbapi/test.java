/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ee4216.miniproject.imdbapi;

import java.util.ArrayList;

/**
 *
 * @author EdwardHe
 */
public class test {
    /*
    public static void main(String[] args) {
        System.out.println("Hello World");
	ArrayList<String> object = new ArrayList<String>();
        object.add("");
        String memo = "[{\"memoID\":1,\"userID\":\"ccc\",\"content\":\"test2\",\"color\":\"test2\",\"top\":0,\"left\":0,\"font\":\"test2\",\"height\":1,\"width\":0},{\"memoID\":1,\"userID\":\"ccc\",\"content\":\"test2\",\"color\":\"test2\",\"top\":0,\"left\":0,\"font\":\"test2\",\"height\":1,\"width\":0}]";
        int j = 0;
        
        memo = memo.replace("[", "");
        memo = memo.replace("]", "");
        int length = memo.length();
        for (int i = 0; i < length; i++)
        {
            char temp = memo.charAt(i);
            System.out.println(temp);
            if (temp == ',' && i != length - 1 && memo.charAt(i+1) == '{'){
                j++;
                object.add("");
            } else {
                
                object.set(j, object.get(j) + temp);
            }
        }
        
        for (int k = 0; k < object.size(); k++)
        {
            System.out.println(object.get(k));
        }
        
    }*/
}
